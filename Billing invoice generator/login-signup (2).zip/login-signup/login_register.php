<?php

require('connection.php');

if(isset($_POST['register']))
{
    $user_exist_query="SELECT * FROM 'registered_users' WHERE 'username'='$_POST[username]' OR 'email'='$_POST[email]'";
    $result=mysqli_query($con,$user_exist_query);

    if($result)
    {
     if(mysqli_num_rows($result)>0)
     {
        #if any user has already taken username or email
        $result_fetch=mysqli_fetch_assoc($result);
        if($result_fetch['username']==$_POST['username'])
        {
            #error for username already registerd
            echo"
            <script>
             alert('$result_fetch[username] - Username alredy taken');
             window.location.href='index.php';
            </scrpit>
            ";   
        }
     }
     else 
     {
        #error for email already registerd
          echo"
          <script>
          alert('$result_fetch[username] - E-mail alredy taken');
          window.location.href='index.php';
        </scrpit>
        ";   
     }
    }
    else #it will be executed if no one has taken username or email before
    {
      $query="INSERT INTO `registered user`(`full_name`, `username`, `email`, `password`) VALUES ('$_POST[fullname]','$_POST[username]','$_POST[email]','$_POST[password]')";  
      if(mysqli_query($con,$query))
      {
      #if data inserted succesfully 
      echo"
      <script>
       alert('Registeration successfull');
       window.location.href='index.php';
      </scrpit>
      ";
      }
      else
      {
        #if data cannot be inserted
        echo"
        <script>
         alert('Cannot Run Query');
         window.location.href='index.php';
        </scrpit>
        "; 
      }
    }
  {
    echo"
   <script>
    alert('Cannot Run Query');
    window.location.href='index.php';
   </scrpit>
   ";
  }
}

?>